//
//  XJMapSDK.h
//  XJMapSDK
//
//  Created by zhangty on 2018/12/12.
//  Copyright © 2018 xunji. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XJmapServices.h"
#import "XJUserInfo.h"
#import "XJMapViewController.h"
//#import "XJHospitalListViewController.h"

#import "XJReachability.h"
#import "XJNavigationController.h"
#import "XJAlertView.h"

#import "XJmapLocationManger.h"
#import "XJLocationInfo.h"
#import "XJIbeaconManager.h"

//! Project version number for XJMapSDK.
FOUNDATION_EXPORT double XJMapSDKVersionNumber;

//! Project version string for XJMapSDK.
FOUNDATION_EXPORT const unsigned char XJMapSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XJMapSDK/PublicHeader.h>


