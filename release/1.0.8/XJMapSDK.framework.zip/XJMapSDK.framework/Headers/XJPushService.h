//
//  XJPushService.h
//  XunDao-iOS
//
//  Created by zhangty on 2017/8/14.
//  Copyright © 2017年 XJmap. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface XJPushService : NSObject

+ (void)presentLocalNoticationText:(NSString *)text;

@end
