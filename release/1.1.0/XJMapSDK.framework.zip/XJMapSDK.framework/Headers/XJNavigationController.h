//
//  XJNavigationController.h
//  XJmapSDK
//
//  Created by zhangty on 17/4/21.
//  Copyright © 2017年 XJmap. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XJNavigationController : UINavigationController

@end
